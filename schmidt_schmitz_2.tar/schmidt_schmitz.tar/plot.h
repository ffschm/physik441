void plot(double (*funcPtr)(double),double xmin, double xmax, int n);
